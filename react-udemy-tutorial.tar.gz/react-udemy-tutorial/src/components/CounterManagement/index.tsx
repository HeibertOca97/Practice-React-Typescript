import React from 'react';
import { CounterManagementProps, CounterManagementState } from './interface';

class CounterManagement extends React.Component<CounterManagementProps, CounterManagementState>{

  constructor(props: CounterManagementProps){
    super(props)

    this.state = {
      counter: 0,
      name: ''
    }
  }

  handleAddClick = () => {
    this.setState(prevState => {
      return {counter: prevState.counter + 1, name: 'Add'};
    }, () => {
      console.log('Agregado exitosamente');
    });
  }
  
  handleMinusClick = () => {
    this.setState(prevState => {
      return {counter: prevState.counter - 1, name: 'Minus'};
    });
  }

  handleAddNameClick = () => {
    this.setState({name: 'Heibert'});
  }

  handleAddLastNameClick = () => {
    this.setState({name: 'Ocaña'});
  }


  render(){
    console.log('render');
    const {ownerName} = this.props;
    const {counter, name} = this.state;
    return (
      <div>
        <h1> Counter Management </h1>
        <h2>OwnerName: {ownerName}</h2>
        <h2>Counter: {counter}</h2>
        <h2>Action: {name}</h2>
        <br />
        <button onClick={this.handleAddClick}>Add</button>
        <button onClick={this.handleMinusClick}>Minus</button>
        <button onClick={this.handleAddNameClick}>Add Name</button>
        <button onClick={this.handleAddLastNameClick}>Add Last name</button>
      </div>
    );
  }
}

export default CounterManagement;