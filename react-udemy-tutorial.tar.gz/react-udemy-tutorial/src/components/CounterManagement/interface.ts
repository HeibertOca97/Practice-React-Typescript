export interface CounterManagementProps {
  ownerName: string;
}

export interface CounterManagementState {
  counter: number;
  name: string;
}